function startApp() {
  alert("Launching Project Plus...");
}

function toggleTab() {
  const tab = document.getElementById('themeTab');
  tab.style.display = tab.style.display === 'block' ? 'none' : 'block';
}

function changeTheme(theme) {
  if (theme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
  } else if (theme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else if (theme === 'system') {
    applySystemTheme(); // Apply based on system preference
  }

  localStorage.setItem('theme', theme);
}

function applySystemTheme() {
  if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
  }
}

// Load saved theme on page load
(function () {
  const savedTheme = localStorage.getItem('theme');
  const themeSelect = document.getElementById('theme-select');

  if (savedTheme === 'light' || savedTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', savedTheme);
    themeSelect.value = savedTheme;
  } else {
    applySystemTheme();
    themeSelect.value = 'system';
  }
})();